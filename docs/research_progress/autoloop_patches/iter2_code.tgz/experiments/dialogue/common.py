"""Shared runners for schema-based and no-schema dialogue experiments."""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Literal, cast

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.outputs import LLMResult

ROOT = Path(__file__).resolve().parents[2]
DATASETS_DIR = ROOT / "datasets"
LOGS_DIR = ROOT / "logs"

if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

Method = Literal["schema", "no_schema", "free_debate", "mad", "mad_synthesis"]

# モデル別の実価格（1M トークンあたり: 入力 / キャッシュ入力 / 出力）。
# OpenAI 公式の gpt-5.4 系料金。以前はモデル非依存の固定単価で計算しており、
# nano/mini のどちらの実価格とも一致しない total_cost_usd を出していた。
_MODEL_PRICING: dict[str, tuple[float, float, float]] = {
    "gpt-5.4-nano": (0.20, 0.02, 1.25),
    "gpt-5.4-mini": (0.75, 0.075, 4.50),
    "gpt-5-nano": (0.05, 0.005, 0.40),
    "gpt-5-mini": (0.25, 0.025, 2.00),
    "gpt-5": (1.25, 0.125, 10.00),
}
# 未知モデルは高い方（mini）で保守的に見積もる。
_DEFAULT_PRICING: tuple[float, float, float] = _MODEL_PRICING["gpt-5.4-mini"]


def _resolve_model() -> str:
    """コスト計算に使うモデル名を返す（llm.py と同じ MODEL 環境変数の解決）."""
    return os.getenv("MODEL") or "gpt-5.4-mini"


def _prices_for(model: str) -> tuple[float, float, float]:
    return _MODEL_PRICING.get(model, _DEFAULT_PRICING)


class TokenUsageTracker(BaseCallbackHandler):
    """Track OpenAI token usage and estimate run cost."""

    def __init__(self, model: str | None = None) -> None:
        # 1 回の run は単一の MODEL で走るため、既定は環境変数から解決する。
        self.model = model or _resolve_model()
        self.prompt_tokens = 0
        self.cached_tokens = 0
        self.completion_tokens = 0
        self.total_tokens = 0

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        token_usage = (response.llm_output or {}).get("token_usage", {})
        self.prompt_tokens += token_usage.get("prompt_tokens", 0)
        self.completion_tokens += token_usage.get("completion_tokens", 0)
        self.total_tokens += token_usage.get("total_tokens", 0)
        details = token_usage.get("prompt_tokens_details") or {}
        self.cached_tokens += details.get("cached_tokens", 0)

    def usage(self) -> dict[str, Any]:
        price_input, price_cached, price_output = _prices_for(self.model)
        non_cached = self.prompt_tokens - self.cached_tokens
        cost = (
            non_cached * price_input
            + self.cached_tokens * price_cached
            + self.completion_tokens * price_output
        ) / 1_000_000
        return {
            "model": self.model,
            "prompt_tokens": self.prompt_tokens,
            "cached_tokens": self.cached_tokens,
            "completion_tokens": self.completion_tokens,
            "total_tokens": self.total_tokens,
            "total_cost_usd": round(cost, 6),
        }


def _parse_json_text(value: Any) -> Any:
    if not isinstance(value, str):
        return value
    text = value.strip()
    if not text:
        return value
    if "```json" in text:
        start = text.find("```json") + len("```json")
        end = text.find("```", start)
        text = text[start:end].strip()
    elif text.startswith("```") and text.endswith("```"):
        text = text[3:-3].strip()
    if not text.startswith("{"):
        return value
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return value


def _jsonable(value: Any) -> Any:
    if hasattr(value, "model_dump"):
        return _jsonable(value.model_dump())
    if hasattr(value, "__dataclass_fields__"):
        return _jsonable(value.__dict__)
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, dict):
        return {k: _jsonable(v) for k, v in value.items()}
    return _parse_json_text(value)


def _record_argument_payload(record: Any) -> Any:
    if record is None:
        return None
    if hasattr(record, "argument"):
        return _parse_json_text(record.argument)
    if isinstance(record, dict) and "argument" in record:
        return _parse_json_text(record["argument"])
    return record


def _record_metadata(record: Any) -> dict[str, Any]:
    if record is None:
        return {}
    result: dict[str, Any] = {}
    keys = (
        "id",
        "round",
        "type",
        "agent",
        "attack",
        "target_id",
        "target_field",
        "target_statement",
        "status",
    )
    for key in keys:
        value = getattr(record, key, None)
        if value is not None:
            result[key] = value
    if isinstance(record, dict):
        for key in keys:
            value = record.get(key)
            if value is not None:
                result[key] = value
    return result


def _record_id(record: Any) -> str | None:
    if record is None:
        return None
    value = getattr(record, "id", None)
    if isinstance(value, str):
        return value
    if isinstance(record, dict) and isinstance(record.get("id"), str):
        return cast(str, record["id"])
    return None


def _format_argument_for_terminal(argument: Any) -> str:
    """Argument payload を JSON schema の形のまま端末表示する."""
    if isinstance(argument, str):
        text = argument.strip()
        return text if text else "(no argument)"

    if not isinstance(argument, dict):
        return "(no argument)"

    return json.dumps(argument, ensure_ascii=False, indent=2)


def _print_argument_turn(record: Any, seen_ids: set[str]) -> None:
    """生成された発話を一度だけ端末へ出す."""
    record_id = _record_id(record)
    if record_id is not None:
        if record_id in seen_ids:
            return
        seen_ids.add(record_id)

    payload = _record_argument_payload(record)
    if payload is None:
        return

    metadata = _record_metadata(record)
    agent = metadata.get("agent", "?")
    argument_type = metadata.get("type", "?")
    round_no = metadata.get("round")
    header_parts = ["[turn]"]
    if round_no is not None:
        header_parts.append(f"round {round_no}")
    header_parts.append(str(agent))
    header_parts.append(str(argument_type))
    if metadata.get("attack"):
        header_parts.append(f"({metadata['attack']} on {metadata.get('target_field', '?')})")
    print(" ".join(header_parts), flush=True)  # noqa: T201
    if record_id is not None:
        print(f"  id: {record_id}", flush=True)  # noqa: T201
    if metadata.get("target_id"):
        print(f"  target: {metadata['target_id']}", flush=True)  # noqa: T201
    if metadata.get("target_statement"):
        print(f"  target_statement: {metadata['target_statement']}", flush=True)  # noqa: T201
    print(_format_argument_for_terminal(payload), flush=True)  # noqa: T201
    print("", flush=True)  # noqa: T201


def _print_stream_update(
    node_name: str, update: dict[str, Any], seen_ids: set[str]
) -> None:
    """LangGraph の node update から発話を拾って端末へ出す."""
    if node_name in {"can_generate_main", "opponent_move", "proponent_move"}:
        record = update.get("current_argument") or update.get("last_generated_argument")
        _print_argument_turn(record, seen_ids)
        return
    if node_name.startswith("validate_"):
        _print_argument_turn(update.get("last_generated_argument"), seen_ids)


def _node_payload(node_name: str, update: dict[str, Any]) -> Any:
    """Return compact public payloads for streamed schema graph updates."""
    if not update:
        return None
    if node_name in {"can_generate_main", "opponent_move", "proponent_move"}:
        record = update.get("current_argument") or update.get("last_generated_argument")
        payload = _record_argument_payload(record)
        if payload is None:
            return None
        result = {"argument": payload}
        metadata = _record_metadata(record)
        if metadata:
            result["metadata"] = metadata
        return result
    if node_name == "resolve_tree_status":
        return {"thread_status": update.get("ag1_thread_status") or update.get("ag2_thread_status")}
    if node_name.startswith("validate_"):
        record = update.get("last_generated_argument")
        payload = _record_argument_payload(record)
        if payload is None:
            return None
        result = {"argument": payload}
        metadata = _record_metadata(record)
        if metadata:
            result["metadata"] = metadata
        return result
    if node_name in {"finish", "finish_with_error"}:
        return _jsonable(update)
    return _jsonable({k: v for k, v in update.items() if v is not None})


def load_topic(path: str | Path) -> tuple[Path, dict[str, Any]]:
    topic_path = Path(path)
    if not topic_path.is_absolute():
        topic_path = ROOT / topic_path
    if not topic_path.exists():
        raise FileNotFoundError(f"Topic JSON not found: {topic_path}")
    data = cast(dict[str, Any], json.loads(topic_path.read_text(encoding="utf-8")))
    for key in ("question", "agent1_stance", "agent2_stance"):
        if key not in data:
            raise ValueError(f"{topic_path} is missing required key: {key}")
    return topic_path, data


def resolve_category(category: str | Path, datasets_dir: Path = DATASETS_DIR) -> Path:
    raw = Path(category)
    path = raw if raw.is_absolute() else datasets_dir / raw
    if not path.is_dir():
        raise FileNotFoundError(f"Category directory not found: {path}")
    return path


def category_topic_files(category: str | Path, datasets_dir: Path = DATASETS_DIR) -> list[Path]:
    category_dir = resolve_category(category, datasets_dir)
    return sorted(p for p in category_dir.glob("*.json") if p.is_file())


def all_topic_files(datasets_dir: Path = DATASETS_DIR) -> list[Path]:
    """datasets/ 配下（全カテゴリ）の topic JSON を集めて返す.

    datasets/ 直下のファイル（config.json 等の設定ファイル）はカテゴリではないので除外する。
    """
    return sorted(p for p in datasets_dir.glob("*/*.json") if p.is_file())


def topic_identity(topic_path: Path) -> tuple[str, str]:
    return topic_path.parent.name, topic_path.stem


def output_path(method: Method, topic_path: Path, output_root: Path, run_index: int | None) -> Path:
    category, topic = topic_identity(topic_path)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    prefix = f"{run_index:02d}_" if run_index is not None else ""
    return output_root / category / topic / f"{prefix}{method}_{timestamp}.json"


def save_log(log: dict[str, Any], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(log, ensure_ascii=False, indent=2, default=str), encoding="utf-8")
    return path


def base_log(
    *,
    method: Method,
    topic_data: dict[str, Any],
    elapsed: float,
    usage: dict[str, Any],
    extra_metrics: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "method": method,
        "question": topic_data["question"],
        "agent1_stance": topic_data["agent1_stance"],
        "agent2_stance": topic_data["agent2_stance"],
        "metrics": {
            "elapsed_seconds": round(elapsed, 3),
            **usage,
            **(extra_metrics or {}),
        },
    }


def _reconstruct_depths(dialogue_history: list[dict[str, Any]]) -> dict[str, int]:
    """dialogue_history（type + target_id）だけから、各発話の dialogue tree 上の深さを
    再構築する（root=main は depth 0）。

    `State.dialogue_nodes` は main argument のスレッドが変わるたびリセットされる
    （nodes.py の _TREE_RESET_FIELDS）ので、実行終了時点の値は debate 全体の木構造を
    表さない。一方 dialogue_history は debate 全体を通じて一度も消えない永続データ
    なので、ここから深さを再計算する方が頑丈。

    再帰的な定義（Definition 4.6: Pの手番の子は、その論証に対するOの defeater 全て）:
    - main: depth 0（新しいフレームの根）。
    - counter が defeat を標的にする: 同じフレーム内の応答なので depth は変わらない。
    - defeat が main を標的にする: フレームの根を攻撃しているので depth は変わらない。
    - defeat が counter を標的にする: その counter は strictly defeat に成功して
      新しいフレームになった、ということなので depth+1（新しいフレームへの最初の攻撃）。
    - defeat が defeat を標的にする: 旧実装が作っていた、rebut を防ぐ undercut ブロッカー
      （type は常に "defeat"）。現在は新しい undercut の論証を作らないので、新しいログには
      現れない。旧ログの再計算のために、ブロック対象と同じフレーム＝depth は変わらない、
      という扱いを残している。
    """
    by_id = {t["id"]: t for t in dialogue_history if isinstance(t.get("id"), str)}
    memo: dict[str, int] = {}

    def depth_of(record_id: str) -> int:
        if record_id in memo:
            return memo[record_id]
        record = by_id.get(record_id)
        if record is None:
            return 0
        memo[record_id] = 0  # 循環防止の仮置き
        if record.get("type") == "main":
            result = 0
        else:
            target_id = record.get("target_id")
            target = by_id.get(target_id) if isinstance(target_id, str) else None
            if target is None or not isinstance(target_id, str):
                result = 0
            else:
                target_depth = depth_of(target_id)
                if record.get("type") == "counter" or target.get("type") in ("main", "defeat"):
                    result = target_depth
                else:  # defeat が counter を標的 = 新フレームへの最初の攻撃
                    result = target_depth + 1
        memo[record_id] = result
        return result

    return {record_id: depth_of(record_id) for record_id in by_id}


def _dialogue_tree_metrics(final_state: dict[str, Any]) -> dict[str, Any]:
    """dialogue tree の探索規模と、勝敗宣言のみの反論の割合を集計する.

    スキーマ導入の主張（(a) 建設的な深い議論を可能にする, (b) 無駄な議論の膨張を防ぐ）
    を評価するための指標。docs/argumentation_model_rebuild_plan.md §8 参照。
    メタ結論の判定語彙は agent.arguments._META_CONCLUSION_PATTERNS と同じものを使う。
    """
    from src.agent.arguments import _META_CONCLUSION_PATTERNS

    dialogue_history = final_state.get("dialogue_history") or []

    total_turns = len(dialogue_history)
    meta_conclusion_count = 0
    attack_turn_count = 0
    for turn in dialogue_history:
        if turn.get("type") not in {"defeat", "counter"}:
            continue
        attack_turn_count += 1
        argument_json = turn.get("argument") or ""
        try:
            payload = json.loads(argument_json) if isinstance(argument_json, str) else argument_json
        except json.JSONDecodeError:
            payload = {}
        rules = (payload or {}).get("Argument", {}).get("rules", []) if isinstance(payload, dict) else []
        consequents = " ".join(
            (rule.get("consequent") or "") for rule in rules if isinstance(rule, dict)
        ).lower()
        if any(pattern in consequents for pattern in _META_CONCLUSION_PATTERNS):
            meta_conclusion_count += 1

    depth_by_id = _reconstruct_depths(dialogue_history)
    depths = list(depth_by_id.values())
    # フレーム数 = main の本数 + strictly defeat に成功して新フレームになった counter の本数
    # （後続の defeat がそれを標的にしている counter を数える）。
    type_by_id = {t["id"]: t.get("type") for t in dialogue_history if isinstance(t.get("id"), str)}
    promoted_counter_ids = {
        t["target_id"]
        for t in dialogue_history
        if t.get("type") == "defeat"
        and isinstance(t.get("target_id"), str)
        and type_by_id.get(t["target_id"]) == "counter"
    }
    frame_count = sum(1 for t in dialogue_history if t.get("type") == "main") + len(
        promoted_counter_ids
    )

    # main argument ごとの決着内訳。status="justified" かつ closed_by_budget=True は
    # 「予算切れによる justified」であり、opponent が本当に手を尽くした結果の
    # 「証明された justified」とは区別する（docs/argumentation_model_rebuild_plan.md §9 #2）。
    main_turns = [t for t in dialogue_history if t.get("type") == "main" and t.get("status")]
    justified_proven = sum(
        1 for t in main_turns if t.get("status") == "justified" and not t.get("closed_by_budget")
    )
    justified_by_budget = sum(
        1 for t in main_turns if t.get("status") == "justified" and t.get("closed_by_budget")
    )
    overruled_count = sum(1 for t in main_turns if t.get("status") == "overruled")
    defensible_count = sum(1 for t in main_turns if t.get("status") == "defensible")

    return {
        "total_dialogue_turns": total_turns,
        "attack_turn_count": attack_turn_count,
        "meta_conclusion_count": meta_conclusion_count,
        "meta_conclusion_rate": (
            round(meta_conclusion_count / attack_turn_count, 3) if attack_turn_count else None
        ),
        "dialogue_tree_node_count": frame_count,
        "dialogue_tree_max_depth": max(depths) if depths else 0,
        "main_argument_count": len(main_turns),
        "justified_proven_count": justified_proven,
        "justified_by_budget_count": justified_by_budget,
        "overruled_count": overruled_count,
        "defensible_count": defensible_count,
    }


def _speech_log(history: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """対話履歴から、評価・分析に必要なフィールドを抜き出す.

    - attack / target_id / target_field / target_statement: 攻撃系の発話が
      どの発話のどの文（結論/前提）を狙ったのか。評価用の自然文変換
      （"I have a counter argument against the opinion {…}"）の代入元になる。
    - status: main argument のスレッド決着（justified / overruled / defensible）。
    - closed_by_budget: その status が、相手が本当に手を尽くした結果（True相当）ではなく、
      探索予算（max_attack_attempts等）の枯渇による打ち切りだったか。特に
      status="justified" のとき、これが True なら「予算切れによるjustified」であり
      「証明されたjustified」ではないことを示す（詳細: docs/argumentation_model_rebuild_plan.md §9 #2）。
    Argument スキーマ（rules/Conc/Ass）自体は変更せず、その1つ上のレイヤーである
    ログエントリにメタ情報を残す。
    """
    from src.agent.two_path_finalization import speech_log

    return speech_log(history)


async def _run_topic_once(
    method: Method,
    topic_file: str | Path,
    *,
    max_turns: int = 3,
    max_attack_attempts: int | None = None,
    max_dialogue_turns: int | None = None,
    output_root: Path = LOGS_DIR,
    run_index: int | None = None,
) -> Path:
    """schema / no_schema 共通の実行ロジック.

    両条件とも同じ LangGraph（討論プロトコル・プロンプト）を使い、
    `State.output_mode` だけを切り替える（no_schema は Argument 本体の rules/Conc/Ass
    スキーマを取り除き、自由記述の natural language として出力させる）。

    `max_dialogue_turns` は、mad/free_debateと対話ターン数（＝主張・反論の機会の総数）を
    揃えて比較するための、全手法共通の絶対上限（省略時は無効）。
    """
    from src.agent.workflow import State, graph

    topic_path, topic_data = load_topic(topic_file)
    tracker = TokenUsageTracker()
    state_kwargs: dict[str, Any] = {
        "question": topic_data["question"],
        "agent1_stance": topic_data["agent1_stance"],
        "agent2_stance": topic_data["agent2_stance"],
        "max_turns": max_turns,
        "additional_context": cast(dict[str, Any], topic_data.get("additional_context", {})),
        "output_mode": method,
    }
    if max_attack_attempts is not None:
        state_kwargs["max_attack_attempts"] = max_attack_attempts
    if max_dialogue_turns is not None:
        state_kwargs["max_dialogue_turns"] = max_dialogue_turns
    graph_input = State(**state_kwargs)

    start = time.perf_counter()
    result: dict[str, Any] = dict(graph_input.__dict__)
    seen_argument_ids: set[str] = set()
    async for event in graph.astream(
        graph_input,  # type: ignore[arg-type]
        config={"callbacks": [tracker]},
        stream_mode="updates",
    ):
        if not isinstance(event, dict):
            continue
        for node_name, update in event.items():
            if not isinstance(update, dict):
                continue
            _print_stream_update(node_name, update, seen_argument_ids)
            result.update(update)
    elapsed = time.perf_counter() - start
    final_state = _jsonable(result)

    log = base_log(
        method=method,
        topic_data=topic_data,
        elapsed=elapsed,
        usage=tracker.usage(),
        extra_metrics=_dialogue_tree_metrics(final_state),
    )
    log["dialogue_history"] = _speech_log(final_state.get("dialogue_history", []))
    log["final_answer"] = final_state.get("final_answer")
    log["integrated_rules"] = final_state.get("integrated_rules", [])
    # consensus_reached=True かつ justification_status が "{ag}_main_justified" なら
    # 本当に justified で決着した。False/"fallback_no_consensus" なら、ラウンド上限や
    # ターン予算切れで統合ルール（またはどちらかの main）を土台にした暫定回答であり、
    # justified はしていない（docs/argumentation_model_rebuild_plan.md §9 #2/#8 参照）。
    log["consensus_reached"] = final_state.get("consensus_reached")
    log["justification_status"] = final_state.get("justification_status")
    # 最終回答の作り方（justified_argument / fallback_full_dialogue_synthesis）と、決着しなかった
    # ときに議論全体から作った統合文。
    log["finalization_path"] = final_state.get("finalization_path")
    if final_state.get("fallback_synthesis"):
        log["fallback_synthesis"] = final_state["fallback_synthesis"]
    # agent 別の「新しい main を出せなかった理由」（出せた場合は空）。
    log["main_unavailable_reasons"] = final_state.get("main_unavailable_reasons") or {}
    # 「出せなかった／認められなかった」試行（反論なし・ブロッカーなし・攻撃不成立など）と理由。
    log["attempt_log"] = final_state.get("attempt_log") or []
    # 議論で主張された優先順位（成立 in_force / 不成立 contested）。発話の履歴には入れていない。
    log["priority_claims"] = [
        claim.model_dump() if hasattr(claim, "model_dump") else claim
        for claim in final_state.get("priority_claims") or []
    ]
    error = final_state.get("error")
    if error is not None:
        log["error"] = error
    path = save_log(log, output_path(method, topic_path, output_root, run_index))
    print(f"[system] log saved -> {path}", flush=True)
    return path


async def run_schema_topic_once(
    topic_file: str | Path,
    *,
    max_turns: int = 3,
    max_attack_attempts: int | None = None,
    max_dialogue_turns: int | None = None,
    output_root: Path = LOGS_DIR,
    run_index: int | None = None,
) -> Path:
    return await _run_topic_once(
        "schema",
        topic_file,
        max_turns=max_turns,
        max_attack_attempts=max_attack_attempts,
        max_dialogue_turns=max_dialogue_turns,
        output_root=output_root,
        run_index=run_index,
    )


async def run_no_schema_topic_once(
    topic_file: str | Path,
    *,
    max_turns: int = 3,
    max_attack_attempts: int | None = None,
    max_dialogue_turns: int | None = None,
    output_root: Path = LOGS_DIR,
    run_index: int | None = None,
) -> Path:
    return await _run_topic_once(
        "no_schema",
        topic_file,
        max_turns=max_turns,
        max_attack_attempts=max_attack_attempts,
        max_dialogue_turns=max_dialogue_turns,
        output_root=output_root,
        run_index=run_index,
    )


async def run_free_debate_topic_once(
    topic_file: str | Path,
    *,
    max_turns: int = 3,
    max_dialogue_turns: int | None = None,
    output_root: Path = LOGS_DIR,
    run_index: int | None = None,
) -> Path:
    """弁証法プロトコルを使わない自由討議ベースラインを1トピック実行する.

    schema/no_schema と異なるグラフ・State（free_debate.FreeDebateState）を使うため、
    `_run_topic_once` を流用せず専用の実行ロジックを持つ。main argument 再試行という
    概念が無いため `max_attack_attempts` は存在しない。

    `max_dialogue_turns` は、schema/no_schemaと対話ターン数を揃えて比較するための、
    全手法共通の絶対上限（省略時は無効。`max_turns`＝ラウンド数とは別軸）。
    """
    from src.agent.free_debate import FreeDebateState, graph_free_debate

    topic_path, topic_data = load_topic(topic_file)
    tracker = TokenUsageTracker()
    fd_kwargs: dict[str, Any] = {
        "question": topic_data["question"],
        "agent1_stance": topic_data["agent1_stance"],
        "agent2_stance": topic_data["agent2_stance"],
        "max_turns": max_turns,
    }
    if max_dialogue_turns is not None:
        fd_kwargs["max_dialogue_turns"] = max_dialogue_turns
    graph_input = FreeDebateState(**fd_kwargs)

    start = time.perf_counter()
    result: dict[str, Any] = dict(graph_input.__dict__)
    async for event in graph_free_debate.astream(
        graph_input,  # type: ignore[arg-type]
        config={"callbacks": [tracker]},
        stream_mode="updates",
    ):
        if not isinstance(event, dict):
            continue
        for node_name, update in event.items():
            if not isinstance(update, dict):
                continue
            if node_name in ("ag1_turn", "ag2_turn") and update.get("dialogue_history"):
                record = update["dialogue_history"][-1]
                print(f"[turn] round {record['round']} {record['agent']}", flush=True)  # noqa: T201
                print(record["argument"], flush=True)  # noqa: T201
                print("", flush=True)  # noqa: T201
            result.update(update)
    elapsed = time.perf_counter() - start

    log = base_log(
        method="free_debate",
        topic_data=topic_data,
        elapsed=elapsed,
        usage=tracker.usage(),
    )
    log["dialogue_history"] = result.get("dialogue_history", [])
    log["final_answer"] = result.get("final_answer")
    log["finalization_path"] = result.get("finalization_path")
    log["fallback_synthesis"] = result.get("fallback_synthesis")
    path = save_log(log, output_path("free_debate", topic_path, output_root, run_index))
    print(f"[system] log saved -> {path}", flush=True)
    return path


async def run_mad_topic_once(
    topic_file: str | Path,
    *,
    max_turns: int = 3,
    max_dialogue_turns: int | None = None,
    use_synthesis: bool = False,
    output_root: Path = LOGS_DIR,
    run_index: int | None = None,
) -> Path:
    """MAD（相互反論型マルチエージェントディベート）ベースラインを1トピック実行する.

    free_debate と同じグラフ構造（schema/no_schema と異なる State）だが、各ターンで
    明示的な反論を要求する点が異なる（`free_debate.graph_free_debate` ではなく
    `mad.graph_mad` を使う）。

    `max_dialogue_turns` は、schema/no_schemaと対話ターン数を揃えて比較するための、
    全手法共通の絶対上限（省略時は無効。`max_turns`＝ラウンド数とは別軸）。

    `use_synthesis`:
    - False（既定）: ラウンド上限後、独立した judge が勝者を決めて最終回答を作る
      純粋なMAD（「統合プロセスの重要性検証」のベースライン）。ログの method は "mad"。
    - True: judge の代わりに、schema/no_schemaと共通の統合プロンプトで止揚による統合を
      行い、その統合ルールを踏まえて最終回答を作る（「議論過程の重要性検証」で
      free_debate/no_schema/schema と揃えて使う）。ログの method は "mad_synthesis"。
    """
    from src.agent.mad import MADState, graph_mad

    topic_path, topic_data = load_topic(topic_file)
    tracker = TokenUsageTracker()
    mad_kwargs: dict[str, Any] = {
        "question": topic_data["question"],
        "agent1_stance": topic_data["agent1_stance"],
        "agent2_stance": topic_data["agent2_stance"],
        "max_turns": max_turns,
        "use_synthesis": use_synthesis,
    }
    if max_dialogue_turns is not None:
        mad_kwargs["max_dialogue_turns"] = max_dialogue_turns
    graph_input = MADState(**mad_kwargs)

    start = time.perf_counter()
    result: dict[str, Any] = dict(graph_input.__dict__)
    async for event in graph_mad.astream(
        graph_input,  # type: ignore[arg-type]
        config={"callbacks": [tracker]},
        stream_mode="updates",
    ):
        if not isinstance(event, dict):
            continue
        for node_name, update in event.items():
            if not isinstance(update, dict):
                continue
            if node_name in ("ag1_turn", "ag2_turn") and update.get("dialogue_history"):
                record = update["dialogue_history"][-1]
                print(f"[turn] round {record['round']} {record['agent']}", flush=True)  # noqa: T201
                print(record["argument"], flush=True)  # noqa: T201
                print("", flush=True)  # noqa: T201
            result.update(update)
    elapsed = time.perf_counter() - start

    method: Method = "mad_synthesis" if use_synthesis else "mad"
    log = base_log(
        method=method,
        topic_data=topic_data,
        elapsed=elapsed,
        usage=tracker.usage(),
    )
    log["dialogue_history"] = result.get("dialogue_history", [])
    log["final_answer"] = result.get("final_answer")
    if use_synthesis:
        integrated_rule = result.get("integrated_rule")
        log["integrated_rules"] = [integrated_rule] if integrated_rule else []
    path = save_log(log, output_path(method, topic_path, output_root, run_index))
    print(f"[system] log saved -> {path}", flush=True)
    return path


async def run_category(
    method: Method,
    category: str | Path,
    *,
    runs: int = 1,
    max_turns: int = 3,
    max_attack_attempts: int | None = None,
    output_root: Path = LOGS_DIR,
    continue_on_error: bool = True,
) -> list[Path]:
    files = category_topic_files(category)
    if not files:
        raise FileNotFoundError(f"No topic JSON files found in category: {category}")
    saved: list[Path] = []
    for topic_file in files:
        print(f"=== [{method}][{topic_file.parent.name}] {topic_file.stem} ===", flush=True)
        for index in range(1, runs + 1):
            try:
                if method == "schema":
                    saved.append(
                        await run_schema_topic_once(
                            topic_file,
                            max_turns=max_turns,
                            max_attack_attempts=max_attack_attempts,
                            output_root=output_root,
                            run_index=index if runs > 1 else None,
                        )
                    )
                else:
                    saved.append(
                        await run_no_schema_topic_once(
                            topic_file,
                            max_turns=max_turns,
                            max_attack_attempts=max_attack_attempts,
                            output_root=output_root,
                            run_index=index if runs > 1 else None,
                        )
                    )
            except Exception as exc:
                print(f"[error] {topic_file}: {exc}", file=sys.stderr, flush=True)
                if not continue_on_error:
                    raise
    return saved


def topic_parser(description: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("json_file", help="Path to a topic JSON file.")
    parser.add_argument("--runs", type=int, default=1, help="Number of runs for this topic.")
    parser.add_argument("--max-turns", type=int, default=3, help="Maximum debate rounds (used by both schema and no-schema).")
    parser.add_argument("--max-attack-attempts", type=int, default=None, help="Per-round main argument retry cap (defaults to State's MAX_ATTACK_ATTEMPTS env default).")
    parser.add_argument("--output-root", type=Path, default=LOGS_DIR, help="Root directory for logs.")
    return parser


def category_parser(description: str) -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=description)
    parser.add_argument("category", help="Category name under datasets/ or a category directory path.")
    parser.add_argument("--runs", type=int, default=1, help="Number of runs per topic.")
    parser.add_argument("--max-turns", type=int, default=3, help="Maximum debate rounds (used by both schema and no-schema).")
    parser.add_argument("--max-attack-attempts", type=int, default=None, help="Per-round main argument retry cap (defaults to State's MAX_ATTACK_ATTEMPTS env default).")
    parser.add_argument("--output-root", type=Path, default=LOGS_DIR, help="Root directory for logs.")
    parser.add_argument("--fail-fast", action="store_true", help="Stop on the first topic failure.")
    return parser


async def run_topic_repeated(method: Method, args: argparse.Namespace) -> list[Path]:
    saved: list[Path] = []
    for index in range(1, args.runs + 1):
        if method == "schema":
            saved.append(
                await run_schema_topic_once(
                    args.json_file,
                    max_turns=args.max_turns,
                    max_attack_attempts=args.max_attack_attempts,
                    output_root=args.output_root,
                    run_index=index if args.runs > 1 else None,
                )
            )
        else:
            saved.append(
                await run_no_schema_topic_once(
                    args.json_file,
                    max_turns=args.max_turns,
                    max_attack_attempts=args.max_attack_attempts,
                    output_root=args.output_root,
                    run_index=index if args.runs > 1 else None,
                )
            )
    return saved


def main_topic(method: Method, description: str) -> None:
    args = topic_parser(description).parse_args()
    asyncio.run(run_topic_repeated(method, args))


def main_category(method: Method, description: str) -> None:
    args = category_parser(description).parse_args()
    asyncio.run(
        run_category(
            method,
            args.category,
            runs=args.runs,
            max_turns=args.max_turns,
            max_attack_attempts=args.max_attack_attempts,
            output_root=args.output_root,
            continue_on_error=not args.fail_fast,
        )
    )
