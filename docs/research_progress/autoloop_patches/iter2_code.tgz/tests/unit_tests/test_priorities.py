"""議論で主張された優先順位（priorities / validate_*_move の判定）の単体テスト."""

from __future__ import annotations

import json
from types import SimpleNamespace
from typing import Any

import pytest

from agent import arguments, nodes, priorities
from agent.argumentation_model import AttackMatch, evaluate_attack
from agent.prompts import attack_extends_instruction, attack_instruction
from agent.schema.llm_outputs import AttackExtendsOutput, DefeatingArgumentOutput
from agent.schema.state import ArgumentRecord, DialogueNode, PriorityClaim
from agent.workflow import State

pytestmark = pytest.mark.anyio


def _record(
    type_: str,
    agent: str,
    conc: str,
    attack: str | None = None,
    ass: list[str] | None = None,
    proponent: str = "AG1",
) -> ArgumentRecord:
    payload = {"Argument": {"rules": [], "Conc": [conc], "Ass": ass or []}}
    return ArgumentRecord(
        type=type_,  # type: ignore[arg-type]
        argument=json.dumps(payload),
        support=[],
        agent=agent,  # type: ignore[arg-type]
        proponent=proponent,  # type: ignore[arg-type]
        attack=attack,  # type: ignore[arg-type]
    )


def _claim(preferred: str, over: str, status: str = "in_force") -> PriorityClaim:
    return PriorityClaim(
        preferred_id=preferred,
        over_id=over,
        claimant="AG1",
        basis="stronger evidence",
        statement=priorities.priority_statement(preferred, over),
        status=status,  # type: ignore[arg-type]
    )


def test_outranks_uses_only_claims_in_force_and_is_transitive() -> None:
    claims = [_claim("c", "b"), _claim("b", "a"), _claim("z", "y", status="contested")]

    assert priorities.outranks(claims, "c", "b")
    assert priorities.outranks(claims, "c", "a")  # 推移律
    assert not priorities.outranks(claims, "a", "c")
    assert not priorities.outranks(claims, "z", "y")  # 争われた優先順位は成立しない


def test_add_claim_puts_the_claim_in_force() -> None:
    claims = priorities.add_claim([], _claim("c", "b", status="contested"))

    assert [c.status for c in claims] == ["in_force"]
    assert priorities.outranks(claims, "c", "b")


def test_add_claim_keeps_neither_side_when_the_reverse_priority_is_already_in_force() -> None:
    claims = priorities.add_claim([_claim("b", "c")], _claim("c", "b"))

    assert all(c.status == "contested" for c in claims)
    assert not priorities.outranks(claims, "b", "c")
    assert not priorities.outranks(claims, "c", "b")


def test_a_priority_statement_is_one_of_the_preferred_arguments_conclusions() -> None:
    claims = [_claim("c", "b"), _claim("x", "y", status="contested")]

    assert priorities.statements_for(claims, "c") == [priorities.priority_statement("c", "b")]
    assert priorities.statements_for(claims, "b") == []
    assert priorities.statements_for(claims, "x") == []  # 不成立の主張は、もう結論ではない


def test_an_attack_on_the_statement_is_recognized_only_for_the_preferred_argument() -> None:
    claims = [_claim("c", "b")]
    statement = priorities.priority_statement("c", "b")

    assert priorities.contested_by(claims, "c", statement) is not None
    assert priorities.contested_by(claims, "c", statement.lower() + ".") is not None
    assert priorities.contested_by(claims, "b", statement) is None
    assert priorities.contested_by(claims, "c", "we should choose a") is None
    assert priorities.contested_by(claims, "c", None) is None


def test_mark_contested_turns_only_that_claim_off() -> None:
    claims = [_claim("c", "b"), _claim("e", "d")]

    updated = priorities.mark_contested(claims, claims[0])

    assert [c.status for c in updated] == ["contested", "in_force"]


def test_priorities_block_lists_claims_in_force_and_explains_how_to_contest_only_when_asked() -> None:
    b = _record("defeat", "AG2", "we should not choose a", attack="rebut")
    c = _record("counter", "AG1", "we should choose a", attack="rebut")
    claims = [_claim(c.id, b.id)]

    plain = priorities.priorities_block(claims, [b, c])
    contestable = priorities.priorities_block(claims, [b, c], contestable=True)

    assert priorities.priority_statement(c.id, b.id) in plain
    assert "stronger evidence" in plain
    assert "To contest one of them" not in plain
    assert "To contest one of them" in contestable
    assert priorities.priorities_block([_claim(c.id, b.id, "contested")], [b, c]) == ""


async def test_a_rebut_outranked_by_its_target_does_not_defeat() -> None:
    target = _record("counter", "AG1", "we should choose a")
    attacker = _record("defeat", "AG2", "we should not choose a", attack="rebut")
    attacker.target_statement = "we should choose a"

    outranked = await evaluate_attack(
        SimpleNamespace(),
        attacker,
        target,
        "AG1",
        relation_context="test",
        outranks=lambda preferred, over: (preferred, over) == (target.id, attacker.id),
    )
    not_outranked = await evaluate_attack(
        SimpleNamespace(),
        attacker,
        target,
        "AG1",
        relation_context="test",
        outranks=lambda preferred, over: False,
    )

    assert outranked.defeats is False
    assert outranked.relations[-1].valid is False
    assert not_outranked.defeats is True


async def test_an_undercut_defeats_even_when_the_target_outranks_it() -> None:
    target = _record("counter", "AG1", "we should choose a", ass=["a is available"])
    attacker = _record("defeat", "AG2", "a is not available", attack="undercut")
    attacker.target_statement = "a is available"

    result = await evaluate_attack(
        SimpleNamespace(),
        attacker,
        target,
        "AG1",
        relation_context="test",
        outranks=lambda preferred, over: True,
    )

    assert result.defeats is True


async def test_an_attack_may_target_a_stated_priority_only_when_it_is_passed_as_a_conclusion() -> None:
    target = _record("counter", "AG1", "we should choose a")
    statement = priorities.priority_statement(target.id, "arg-b")
    attacker = _record("defeat", "AG2", "arg-b outranks the counter", attack="rebut")
    attacker.target_statement = statement

    without = await evaluate_attack(
        SimpleNamespace(), attacker, target, "AG1", relation_context="test"
    )
    with_statement = await evaluate_attack(
        SimpleNamespace(),
        attacker,
        target,
        "AG1",
        relation_context="test",
        extra_conclusions=[statement],
    )

    assert without.defeats is False
    assert with_statement.defeats is True


def _frame_state(
    frame_argument: ArgumentRecord,
    records: list[ArgumentRecord],
    claims: list[PriorityClaim],
    *,
    pending_counter: ArgumentRecord | None = None,
    pending_attacker: ArgumentRecord | None = None,
    current_attacker: ArgumentRecord | None = None,
) -> State:
    root = DialogueNode(
        argument_id=frame_argument.id,
        current_attacker_id=current_attacker.id if current_attacker else None,
    )
    return State(
        question="Q?",
        agent1_stance="s1",
        agent2_stance="s2",
        current_argument=frame_argument,
        current_proponent="AG1",
        current_opponent="AG2",
        pending_counter_argument=pending_counter,
        pending_attacker_argument=pending_attacker,
        argument_records=records,
        dialogue_nodes=[root],
        node_stack=[root.id],
        priority_claims=claims,
    )


def _scenario() -> tuple[ArgumentRecord, ArgumentRecord, ArgumentRecord]:
    a = _record("main", "AG1", "we should choose a")
    b = _record("defeat", "AG2", "we should not choose a", attack="rebut")
    b.target_id = a.id
    b.target_statement = "we should choose a"
    c = _record("counter", "AG1", "we should choose a, because of the benefit", attack="rebut")
    c.target_id = b.id
    c.target_statement = "we should not choose a"
    return a, b, c


async def _validate_counter(
    monkeypatch: pytest.MonkeyPatch,
    state: State,
    *,
    reverse: AttackMatch,
) -> dict[str, Any]:
    async def reaches_back(*_args: Any, **_kwargs: Any) -> AttackMatch:
        return reverse

    async def never_undercuts(*_args: Any, **_kwargs: Any) -> None:
        return None

    monkeypatch.setattr(nodes, "ask_attack_extends", reaches_back)
    monkeypatch.setattr(nodes, "ask_existing_undercut", never_undercuts)
    return await nodes.validate_proponent_move(state)


_B_ATTACKS_C = AttackMatch(
    method="rebut", field="Conc", statement="we should choose a, because of the benefit"
)


async def test_counter_that_states_a_priority_strictly_defeats_the_attack_at_once(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    a, b, c = _scenario()
    c.priority_basis = "the benefit is larger than the harm"
    state = _frame_state(a, [a, b, c], [], pending_counter=c, current_attacker=b)

    update = await _validate_counter(monkeypatch, state, reverse=_B_ATTACKS_C)

    # 相手に受け入れを求めない。主張は、その場で、B が C を defeat しない根拠として使われる。
    assert update["last_counter_strictly_defeated"] is True
    [claim] = update["priority_claims"]
    assert (claim.preferred_id, claim.over_id, claim.status) == (c.id, b.id, "in_force")
    assert claim.statement == priorities.priority_statement(c.id, b.id)
    assert update["attempt_log"][-1]["kind"] == "priority_in_force"


async def test_counter_without_a_priority_leaves_the_two_rebuts_defeating_each_other(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    a, b, c = _scenario()
    state = _frame_state(a, [a, b, c], [], pending_counter=c, current_attacker=b)

    update = await _validate_counter(monkeypatch, state, reverse=_B_ATTACKS_C)

    assert update["last_counter_strictly_defeated"] is False
    assert update["priority_claims"] == []


async def test_a_priority_does_not_help_against_an_undercut_and_is_not_recorded(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    a, b, c = _scenario()
    c.argument = json.dumps(
        {"Argument": {"rules": [], "Conc": ["we should choose a"], "Ass": ["a is available"]}}
    )
    c.priority_basis = "the benefit is larger than the harm"
    state = _frame_state(a, [a, b, c], [], pending_counter=c, current_attacker=b)
    undercut = AttackMatch(method="undercut", field="Ass", statement="a is available")

    update = await _validate_counter(monkeypatch, state, reverse=undercut)

    assert update["last_counter_strictly_defeated"] is False
    assert update["priority_claims"] == []


async def _validate_attack(
    monkeypatch: pytest.MonkeyPatch, state: State
) -> dict[str, Any]:
    async def never_undercuts(*_args: Any, **_kwargs: Any) -> None:
        return None

    monkeypatch.setattr(nodes, "ask_existing_undercut", never_undercuts)
    return await nodes.validate_opponent_move(state)


async def test_an_attack_on_the_priority_statement_that_defeats_makes_it_not_hold(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    a, b, c = _scenario()
    claim = _claim(c.id, b.id)
    d = _record("defeat", "AG2", "b outranks c", attack="rebut")
    d.target_id = c.id
    d.target_statement = claim.statement
    state = _frame_state(c, [a, b, c, d], [claim], pending_attacker=d)

    update = await _validate_attack(monkeypatch, state)

    assert update["last_attack_defeated"] is True
    assert [x.status for x in update["priority_claims"]] == ["contested"]
    assert update["attempt_log"][-1]["kind"] == "priority_contested"


async def test_an_attack_on_something_else_leaves_the_priority_in_force(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    a, b, c = _scenario()
    claim = _claim(c.id, b.id)
    d = _record("defeat", "AG2", "we should not choose a at all", attack="rebut")
    d.target_id = c.id
    d.target_statement = "we should choose a, because of the benefit"
    state = _frame_state(c, [a, b, c, d], [claim], pending_attacker=d)

    update = await _validate_attack(monkeypatch, state)

    assert update["last_attack_defeated"] is True
    assert "priority_claims" not in update


def test_priority_basis_is_not_part_of_the_serialized_record() -> None:
    record = _record("counter", "AG1", "we should choose a", attack="rebut")
    record.priority_basis = "the benefit is larger than the harm"

    assert "priority_basis" not in record.model_dump()
    assert "priority_basis" not in record.to_dialogue_dict()
    assert "larger than the harm" not in arguments.argument_message_content(record)


def test_the_instructions_show_priorities_in_force_and_how_to_contest_them() -> None:
    a, b, c = _scenario()
    c.priority_basis = "the benefit is larger than the harm"
    state = SimpleNamespace(
        question="Q?",
        debate_round=1,
        priority_claims=[_claim(c.id, b.id)],
        argument_records=[a, b, c],
    )

    counter = attack_instruction("counter", b, state=state, main_argument=a)
    defeat = attack_instruction("defeat", c, state=state)
    extends = attack_extends_instruction(b, c, state=state)

    assert "<priorities_in_force>" in counter and "<priorities_in_force>" in defeat
    assert "<priority>" in counter and "<priority>" not in defeat
    assert "To contest one of them" in defeat and "To contest one of them" not in counter
    assert "priority" not in extends  # 受け入れを問わない。攻撃の関係だけを問う


def test_the_output_schemas_carry_the_priority_field_but_no_acceptance_question() -> None:
    assert "Priority" in DefeatingArgumentOutput.model_fields
    assert "accepts_priority" not in AttackExtendsOutput.model_fields
