"""議論で主張された優先順位（Prakken & Sartor の `r ≺ r'`）を、状態として扱う補助関数.

優先順位は、反撃 C が「自分は攻撃 B より優先される」と、自分の手の中で主張したもの。
論文の証明手続き（Def 6.1）に合わせて、P の手は、自分の手で述べた優先順位を、その手が
strictly defeat かの判定にすぐ使える。反論側（O）は、優先順位を考慮せず、次の自分の攻撃で、
その主張の文を標的にして争える（優先順位の主張は、C の結論の1つ）。争いが defeat になれば、
その優先順位は不成立になる。

優先順位は、発話の履歴には入れず、議論の状態で管理する。各発話の指示文には、成立している
優先順位を、外部ルールの形で渡す。成立した優先順位には推移律を使い、逆向きの優先順位とは
両立させない（論文の公理: 非対称律）。
"""

from __future__ import annotations

from collections.abc import Sequence

from .schema.state import ArgumentRecord, PriorityClaim

_MAX_BLOCK_CLAIMS = 6
_LABEL_CONCLUSION_CHARS = 110


def priority_statement(preferred_id: str, over_id: str) -> str:
    """優先順位の主張の文（反論側が、この文を標的にして争う）."""
    return f"Argument {preferred_id} outranks argument {over_id}"


def _normalize(text: str) -> str:
    return " ".join(text.split()).strip().rstrip(".").lower()


def in_force(claims: Sequence[PriorityClaim]) -> list[PriorityClaim]:
    """成立している優先順位だけを返す."""
    return [claim for claim in claims if claim.status == "in_force"]


def outranks(claims: Sequence[PriorityClaim], preferred_id: str, over_id: str) -> bool:
    """成立している優先順位（推移律込み）で、preferred が over より優先されるか."""
    edges: dict[str, set[str]] = {}
    for claim in in_force(claims):
        edges.setdefault(claim.preferred_id, set()).add(claim.over_id)
    seen: set[str] = set()
    stack = [preferred_id]
    while stack:
        current = stack.pop()
        for nxt in edges.get(current, ()):
            if nxt == over_id:
                return True
            if nxt not in seen:
                seen.add(nxt)
                stack.append(nxt)
    return False


def add_claim(claims: Sequence[PriorityClaim], claim: PriorityClaim) -> list[PriorityClaim]:
    """主張された優先順位を、簿記に加える（成立として）.

    成立している逆向きの優先順位がある（非対称律に反する）ときは、新しい主張も、逆向きの
    主張も、成立させない（懐疑的な扱い）。
    """
    updated = list(claims)
    if outranks(updated, claim.over_id, claim.preferred_id):
        contested = [
            existing.model_copy(update={"status": "contested"})
            if existing.status == "in_force"
            and existing.preferred_id == claim.over_id
            and existing.over_id == claim.preferred_id
            else existing
            for existing in updated
        ]
        return [*contested, claim.model_copy(update={"status": "contested"})]
    return [*updated, claim.model_copy(update={"status": "in_force"})]


def statements_for(claims: Sequence[PriorityClaim], argument_id: str) -> list[str]:
    """argument_id が優先される側として、成立している優先順位の主張の文（その論証の結論の1つ）."""
    return [c.statement for c in in_force(claims) if c.preferred_id == argument_id]


def contested_by(
    claims: Sequence[PriorityClaim], target_id: str, target_statement: str | None
) -> PriorityClaim | None:
    """攻撃の標的（target_id の論証、target_statement の文）が、成立している優先順位の主張か."""
    if not target_statement:
        return None
    wanted = _normalize(target_statement)
    for claim in in_force(claims):
        if claim.preferred_id == target_id and _normalize(claim.statement) == wanted:
            return claim
    return None


def mark_contested(
    claims: Sequence[PriorityClaim], contested: PriorityClaim
) -> list[PriorityClaim]:
    """争われた優先順位を不成立にする."""
    return [
        claim.model_copy(update={"status": "contested"})
        if claim.preferred_id == contested.preferred_id
        and claim.over_id == contested.over_id
        and claim.status == "in_force"
        else claim
        for claim in claims
    ]


def _label(record: ArgumentRecord | None, record_id: str) -> str:
    if record is None:
        return record_id
    conclusions = record.conclusions
    summary = conclusions[-1] if conclusions else record.argument
    summary = " ".join(summary.split())
    if len(summary) > _LABEL_CONCLUSION_CHARS:
        summary = summary[: _LABEL_CONCLUSION_CHARS - 1] + "…"
    return f'{record.agent}\'s argument {record_id} ("{summary}")'


def priorities_block(
    claims: Sequence[PriorityClaim],
    records: Sequence[ArgumentRecord],
    *,
    contestable: bool = False,
) -> str:
    """各発話の指示文に渡す、成立している優先順位のブロック（無ければ空文字）.

    contestable=True（反論側の攻撃）のときは、争い方も添える。
    """
    active = in_force(claims)[-_MAX_BLOCK_CLAIMS:]
    if not active:
        return ""
    by_id = {record.id: record for record in records}
    lines = [
        "<priorities_in_force>",
        "These priorities have been stated in this debate and have not been successfully "
        "contested. An argument that is outranked cannot defeat, by rebuttal, the argument "
        "that outranks it.",
    ]
    for claim in active:
        lines.append(
            f'- "{claim.statement}": {_label(by_id.get(claim.preferred_id), claim.preferred_id)} '
            f"outranks {_label(by_id.get(claim.over_id), claim.over_id)}. Basis: {claim.basis}"
        )
    if contestable:
        lines.append(
            "To contest one of them, attack it: declare an Attack on field Conc whose target "
            "statement is exactly the quoted sentence, and argue that the opposite ordering "
            "holds. If your attack defeats the argument, that priority no longer holds."
        )
    lines.append("</priorities_in_force>")
    return "\n".join(lines)
