"""Dialect-MAS source package."""
